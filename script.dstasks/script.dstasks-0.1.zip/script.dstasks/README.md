xbmc-dstasks
==============

Manage Synology Download Station tasks in XBMC
