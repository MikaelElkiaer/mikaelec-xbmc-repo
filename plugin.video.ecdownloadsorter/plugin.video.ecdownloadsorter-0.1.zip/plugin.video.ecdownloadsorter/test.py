import os
import sys

sys.path.append(os.path.abspath("plugin.video.ecdownloadsorter/resources/lib/"))

from unsorted import unsorted

Unsorted = unsorted('192.168.1.27', 'admin', 'p0nyl0ver', 'download')

Unsorted.login()

Unsorted.move("test", ["media", "sport"])

Unsorted.logout()